#' @rdname margins
#' @importFrom prediction find_data
#' @export
margins.polr <- margins.nnet
