#' @rdname cplot
#' @export
cplot.glm <- cplot.lm
