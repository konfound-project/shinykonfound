#' @rdname marginal_effects
#' @importFrom prediction find_data
#' @export
marginal_effects.polr <- marginal_effects.nnet
