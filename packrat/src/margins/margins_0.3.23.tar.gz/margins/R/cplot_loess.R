#' @rdname cplot
#' @export
cplot.loess <- cplot.lm
