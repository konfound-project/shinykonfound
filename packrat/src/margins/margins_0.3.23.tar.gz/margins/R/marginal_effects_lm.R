#' @rdname marginal_effects
#' @export
marginal_effects.lm <- marginal_effects.glm
