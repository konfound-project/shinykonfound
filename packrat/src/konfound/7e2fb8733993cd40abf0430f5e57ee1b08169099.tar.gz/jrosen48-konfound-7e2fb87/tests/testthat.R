library(testthat)
library(konfound)

test_check("konfound")
