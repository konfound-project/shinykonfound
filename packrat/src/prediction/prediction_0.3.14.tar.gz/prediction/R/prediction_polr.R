#' @rdname prediction
#' @export
prediction.polr <- prediction.multinom
